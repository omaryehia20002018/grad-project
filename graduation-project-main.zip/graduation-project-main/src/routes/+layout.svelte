<script lang='ts'>
  import '$lib/styles/styles.css'
</script>

<slot />

<style lang='scss'>
  
</style>