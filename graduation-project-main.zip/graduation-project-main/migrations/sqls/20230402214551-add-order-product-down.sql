
DROP TABLE order_products;